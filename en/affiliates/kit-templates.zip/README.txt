PROMO KIT: BUDGET PLANNER AND DEBT PAYOFF TRACKER
Replace [YOUR LINK] with your Hotmart affiliate link. Commission: 50%.
Rules: do not promise financial results, do not invent testimonials, do not present the templates as professional financial advice.

== Social post ==
Do you know how much of last month's paycheck is left? 🤔
The Monthly Budget Planner shows income, expenses, savings and your savings rate on a dashboard with charts that update as you type.
✅ 12 monthly tabs, planned vs. actual
✅ Bills "Paid?" checklist
✅ 5 savings goals with progress bars
Works in Google Sheets and Excel. US$ 9.90, one-time payment.
👉 [YOUR LINK]

== Debt post ==
Debt snowball or avalanche: which one gets you out of debt faster?
The Debt Payoff Tracker compares both side by side (months, interest and total paid) and shows your estimated debt-free date, with how much to pay on each debt every month.
Up to 10 debts: credit cards, car loans, student loans, personal loans. Google Sheets and Excel, US$ 12.90.
👉 [YOUR LINK]

== Blog paragraph ==
If you'd rather use a ready-made tool, the Monthly Budget Planner (US$ 9.90) does the math for you: enter income and spending, and the dashboard shows what's left, what you saved and where the money went, month by month. For readers with several debts, the Debt Payoff Tracker (US$ 12.90) compares the snowball and avalanche methods and builds the payment calendar. Both work in Google Sheets and Excel. [YOUR LINK]

== Newsletter ==
Subject: the spreadsheet I'd use to plan the month
Quick tip: if you want to start tracking spending without fuss, the Monthly Budget Planner builds the monthly dashboard for you, with charts and savings goals. US$ 9.90, works in Google Sheets and Excel: [YOUR LINK]

== Free tools to link alongside ==
Free monthly budget template: https://araujo19con.github.io/questaodiaria/en/free-budget-template/
Debt snowball calculator: https://araujo19con.github.io/questaodiaria/en/debt-snowball-calculator/
50/30/20 calculator: https://araujo19con.github.io/questaodiaria/en/50-30-20-calculator/
Emergency fund calculator: https://araujo19con.github.io/questaodiaria/en/emergency-fund-calculator/
